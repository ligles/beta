Aauth V2 Database
-----------------

- First open your database (or create one if you have not already done so)
- Execute sql "Aauth_v2.sql" file in your database
- If you have not already, don't forget to change database connection settings in application/config/database.php

That's All :) 
